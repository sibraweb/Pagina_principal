# Arquitectura del rediseño

## Criterio general

La home se deja como landing institucional modular. Los datos que cambian seguido no quedan hardcodeados en el HTML, sino en `js/site.config.js`.

## Por qué no está todo en un solo HTML

- `index.html`: estructura semántica y secciones principales.
- `css/tokens.css`: fuente de verdad visual para colores, radios, sombras y tipografía.
- `css/styles.css`: componentes, layout y responsive.
- `js/site.config.js`: contactos, redes, unidades de negocio y enlaces.
- `js/main.js`: lógica del menú, formulario, renderizado de cards y enlaces de WhatsApp.
- `server.py`: sólo para probar localmente guardando leads en CSV.

## Hosting

La web puede funcionar como sitio estático. El formulario abre WhatsApp aunque no exista backend. Si se quiere persistir leads en producción, después conviene conectar el formulario a:

- Google Sheets vía Apps Script o n8n.
- Endpoint propio en Flask/FastAPI.
- Servicio de formularios externo.

## Subpáginas

Las subpáginas están preparadas en `/pages`, pero por ahora son placeholders. Para construirlas, duplicar `templates/subpage-template.html` y completar contenido.
