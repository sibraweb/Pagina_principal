# Gestión de imágenes y logos

## Carpetas

```text
assets/logos/source/       # originales tal como los manda el diseñador o cliente
assets/logos/svg-draft/    # versiones SVG editables de trabajo
assets/logos/transparent/  # PNG/SVG con fondo transparente para fondos claros
assets/logos/dark/         # versiones para fondo negro/gris oscuro
assets/img/raw/            # fotos o imágenes originales pesadas
assets/img/optimized/      # imágenes comprimidas para web
assets/icons/social/       # íconos sociales si se decide no usar inline SVG
```

## Regla de trabajo

Nunca editar directamente los originales. Copiar desde `raw` o `source`, optimizar y guardar la versión web en `optimized`, `transparent` o `dark`.

## Formatos recomendados

- Logos: SVG si es vectorial; PNG transparente si viene de imagen.
- Fotos: JPG/WebP optimizado.
- Capturas UI: PNG/WebP.
- Íconos: SVG.
