# Flujo de leads

## Configuración actual

Archivo principal: `js/site.config.js`

```js
contact: {
  visibleWhatsapp: "+54 911 2165 1864",
  whatsappNumber: "5491126161864",
  contactEmail: "info@sibratech.com",
  formEmail: "contacto@sibratech.com"
}
```

## Comportamiento del formulario

1. El usuario completa los campos.
2. `main.js` arma un mensaje estructurado.
3. Si la página corre con `server.py`, intenta guardar el lead en `data/leads.csv` usando `/api/lead`.
4. Siempre abre WhatsApp con el mensaje listo para enviar.

## Importante

Se mantiene `formEmail: contacto@sibratech.com` para no romper el flujo anterior. En la web visible se muestra `info@sibratech.com`.
