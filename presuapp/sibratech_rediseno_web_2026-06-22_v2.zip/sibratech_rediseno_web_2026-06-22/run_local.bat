@echo off
cd /d "%~dp0"
echo ==========================================
echo  SIBRATECH WEB LOCAL
echo ==========================================
echo.
echo Abriendo servidor local en http://localhost:8080
echo Para cerrar, presionar CTRL+C en esta ventana.
echo.
python server.py
pause
