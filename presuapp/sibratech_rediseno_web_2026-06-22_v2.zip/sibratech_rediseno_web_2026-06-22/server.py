#!/usr/bin/env python3
"""
Servidor local simple para probar la web de Sibratech y guardar leads en CSV.

Uso:
  python server.py
  abrir http://localhost:8080

En hosting estático, el formulario igual abre WhatsApp; el guardado CSV es sólo para pruebas/local.
"""
from __future__ import annotations

import csv
import json
from datetime import datetime
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
LEADS_CSV = DATA_DIR / "leads.csv"
HOST = "127.0.0.1"
PORT = 8080

FIELDS = [
    "created_at",
    "name",
    "company",
    "phone",
    "email",
    "area",
    "message",
    "formEmail",
    "source",
]


class SibratechHandler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def _send_json(self, status: int, payload: dict) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self) -> None:  # noqa: N802
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_POST(self) -> None:  # noqa: N802
        path = urlparse(self.path).path
        if path != "/api/lead":
            self._send_json(404, {"ok": False, "error": "Ruta no encontrada"})
            return

        try:
            content_length = int(self.headers.get("Content-Length", "0"))
            raw = self.rfile.read(content_length)
            lead = json.loads(raw.decode("utf-8"))
        except Exception as exc:  # pragma: no cover
            self._send_json(400, {"ok": False, "error": f"JSON inválido: {exc}"})
            return

        required = ["name", "phone", "area", "message"]
        missing = [field for field in required if not str(lead.get(field, "")).strip()]
        if missing:
            self._send_json(422, {"ok": False, "error": "Faltan campos requeridos", "missing": missing})
            return

        DATA_DIR.mkdir(exist_ok=True)
        is_new = not LEADS_CSV.exists()
        row = {field: lead.get(field, "") for field in FIELDS}
        row["created_at"] = datetime.now().isoformat(timespec="seconds")

        with LEADS_CSV.open("a", newline="", encoding="utf-8") as fh:
            writer = csv.DictWriter(fh, fieldnames=FIELDS)
            if is_new:
                writer.writeheader()
            writer.writerow(row)

        self._send_json(200, {"ok": True, "saved_to": str(LEADS_CSV.relative_to(ROOT))})


if __name__ == "__main__":
    print(f"Sibratech local server: http://localhost:{PORT}")
    print("Ctrl+C para cerrar")
    ThreadingHTTPServer((HOST, PORT), SibratechHandler).serve_forever()
