window.SIBRATECH_CONFIG = {
  brand: {
    name: "Sibratech Group",
    legalName: "Sibratech SRL",
    slogan: "Construyendo oportunidades",
    cuit: "30-71556869-9",
    ceo: "Juan Esteban Brade"
  },
  contact: {
    address: "Arturo Jauretche 2555, Corrientes, Argentina",
    visibleWhatsapp: "+54 911 2165 1864",
    whatsappNumber: "5491126161864",
    contactEmail: "info@sibratech.com",
    formEmail: "contacto@sibratech.com",
    instagramHandle: "@sibratech"
  },
  urls: {
    site: "https://www.sibratech.com",
    legacySite: "https://sibratech.com.ar",
    whatsappBase: "https://wa.me/",
    repo: "https://github.com/sibraweb/Pagina_principal"
  },
  social: [
    { id: "instagram", label: "Instagram", url: "https://www.instagram.com/sibratech/" },
    { id: "whatsapp", label: "WhatsApp", url: "https://wa.me/5491126161864" },
    { id: "linkedin", label: "LinkedIn", url: "#" },
    { id: "substack", label: "Substack", url: "#" },
    { id: "youtube", label: "YouTube", url: "#" }
  ],
  units: [
    {
      key: "group",
      name: "Sibratech Group",
      tagline: "Estructuración Integral de Proyectos",
      description: "Integramos capacidades técnicas, financieras y digitales para ordenar proyectos complejos.",
      page: "pages/group.html",
      watermark: "G"
    },
    {
      key: "constructora",
      name: "Sibratech Constructora",
      tagline: "Obra · Industria · Estructura",
      description: "Ejecutamos y acompañamos obras con planificación, control y mirada industrial.",
      page: "pages/constructora.html",
      watermark: "C"
    },
    {
      key: "gestion",
      name: "Sibratech Gestión",
      tagline: "Gestión de Proyectos · Consultoría",
      description: "Diseñamos sistemas de gestión, tableros y procesos para obras y empresas.",
      page: "pages/gestion.html",
      watermark: "G"
    },
    {
      key: "investors",
      name: "Sibra Investors",
      tagline: "Asesoría Financiera a Empresas y Personas",
      description: "Ayudamos a analizar decisiones de inversión, financiamiento y asignación de capital.",
      page: "pages/investors.html",
      watermark: "I"
    },
    {
      key: "internacional",
      name: "Sibratech Internacional",
      tagline: "Importaciones · Comercio Exterior",
      description: "Conectamos oportunidades, proveedores y soluciones internacionales para proyectos locales.",
      page: "pages/internacional.html",
      watermark: "X"
    },
    {
      key: "consultoria-it",
      name: "Sibratech Consultoría & Desarrollos IT",
      tagline: "Transformación Digital · Desarrollos a Medida",
      description: "Creamos herramientas digitales, automatizaciones y sistemas internos para decidir mejor.",
      page: "pages/consultoria-it.html",
      watermark: "IT"
    }
  ]
};
