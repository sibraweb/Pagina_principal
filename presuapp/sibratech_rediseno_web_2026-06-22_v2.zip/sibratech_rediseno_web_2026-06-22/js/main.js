(function () {
  const config = window.SIBRATECH_CONFIG;
  const icons = window.SIBRATECH_ICONS || {};

  const $ = (selector, parent = document) => parent.querySelector(selector);
  const $$ = (selector, parent = document) => Array.from(parent.querySelectorAll(selector));

  function iconForUnit(key) {
    const common = 'viewBox="0 0 64 64" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"';
    const map = {
      group: `<svg class="unit-icon" ${common}><rect x="10" y="10" width="12" height="12"/><rect x="26" y="10" width="12" height="12"/><rect x="42" y="10" width="12" height="12"/><rect x="10" y="26" width="12" height="12"/><rect x="26" y="26" width="12" height="12"/><rect x="42" y="26" width="12" height="12"/><rect x="10" y="42" width="12" height="12"/><rect x="26" y="42" width="12" height="12"/><rect x="42" y="42" width="12" height="12"/></svg>`,
      constructora: `<svg class="unit-icon" ${common}><path d="M10 46h44"/><path d="M14 42 30 26l8 8 12-12"/><path d="M24 42 40 26l8 8"/><path d="M12 52h40"/></svg>`,
      gestion: `<svg class="unit-icon" ${common}><circle cx="16" cy="18" r="5"/><circle cx="46" cy="18" r="5"/><circle cx="32" cy="46" r="5"/><path d="M21 19h20M18.5 23l10.5 18M44 23 35 41"/></svg>`,
      investors: `<svg class="unit-icon" ${common}><path d="M12 50h40"/><rect x="16" y="34" width="7" height="16"/><rect x="29" y="26" width="7" height="24"/><rect x="42" y="16" width="7" height="34"/><path d="M15 23c10 0 18-5 28-14"/></svg>`,
      internacional: `<svg class="unit-icon" ${common}><circle cx="32" cy="32" r="17"/><path d="M15 32h34M32 15c5 5 7 11 7 17s-2 12-7 17M32 15c-5 5-7 11-7 17s2 12 7 17"/><path d="M10 22c9-8 29-11 44-2"/></svg>`,
      "consultoria-it": `<svg class="unit-icon" ${common}><path d="M44 16H27a9 9 0 0 0 0 18h10a9 9 0 0 1 0 18H18"/><path d="M44 16l5-5M18 52l-5 5"/><circle cx="51" cy="9" r="3"/><circle cx="11" cy="59" r="3"/><path d="M22 25h-8M50 43h-8"/></svg>`
    };
    return map[key] || map.group;
  }

  function buildWhatsappUrl(message) {
    const base = `${config.urls.whatsappBase}${config.contact.whatsappNumber}`;
    return `${base}?text=${encodeURIComponent(message || 'Hola Sibratech, quiero hacer una consulta desde la web.')}`;
  }

  function hydrateContact() {
    $$('[data-whatsapp-link]').forEach((link) => {
      link.href = buildWhatsappUrl();
      link.target = '_blank';
      link.rel = 'noopener';
    });
    $$('[data-visible-whatsapp]').forEach((el) => { el.textContent = config.contact.visibleWhatsapp; });
    $$('[data-visible-email]').forEach((el) => { el.textContent = config.contact.contactEmail; });
    $$('[data-email-link]').forEach((link) => { link.href = `mailto:${config.contact.contactEmail}`; });
    $$('[data-address]').forEach((el) => { el.textContent = config.contact.address; });
    $$('[data-year]').forEach((el) => { el.textContent = new Date().getFullYear(); });
  }

  function renderUnits() {
    const grid = $('[data-units-grid]');
    const footer = $('[data-footer-units]');
    if (grid) {
      grid.innerHTML = config.units.map((unit, index) => `
        <article class="unit-card reveal" data-watermark="${unit.watermark}" style="transition-delay:${Math.min(index * 35, 160)}ms">
          <div>
            ${iconForUnit(unit.key)}
            <h3>${unit.name}</h3>
            <p>${unit.description}</p>
          </div>
          <a href="${unit.page}" aria-label="Ver más sobre ${unit.name}"><small>Ver más →</small></a>
        </article>
      `).join('');
    }
    if (footer) {
      footer.innerHTML = config.units.map((unit) => `<a href="${unit.page}">${unit.name.replace('Sibratech ', '').replace('Sibra ', '')}</a>`).join('');
    }
  }

  function renderSocial() {
    const row = $('[data-social-row]');
    if (!row) return;
    row.innerHTML = config.social.map((item) => `
      <a href="${item.url}" target="_blank" rel="noopener" aria-label="${item.label}" title="${item.label}">
        ${icons[item.id] || item.label.charAt(0)}
      </a>
    `).join('');
  }

  function setupNav() {
    const toggle = $('[data-nav-toggle]');
    const menu = $('[data-nav-menu]');
    const header = $('[data-header]');
    if (toggle && menu) {
      toggle.addEventListener('click', () => {
        const open = menu.classList.toggle('is-open');
        toggle.setAttribute('aria-expanded', String(open));
      });
      $$('#nav-menu a').forEach((link) => link.addEventListener('click', () => {
        menu.classList.remove('is-open');
        toggle.setAttribute('aria-expanded', 'false');
      }));
    }
    if (header) {
      const sync = () => header.classList.toggle('is-scrolled', window.scrollY > 12);
      sync();
      window.addEventListener('scroll', sync, { passive: true });
    }
  }

  function setupReveal() {
    const items = $$('.reveal');
    if (!('IntersectionObserver' in window)) {
      items.forEach((el) => el.classList.add('is-visible'));
      return;
    }
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12 });
    items.forEach((el) => observer.observe(el));
  }

  function formToObject(form) {
    const data = new FormData(form);
    return Object.fromEntries(data.entries());
  }

  function buildLeadMessage(lead) {
    return [
      'Hola Sibratech, quiero hacer una consulta desde la web.',
      `Nombre: ${lead.name || '-'}`,
      `Empresa: ${lead.company || '-'}`,
      `Teléfono: ${lead.phone || '-'}`,
      `Email: ${lead.email || '-'}`,
      `Área: ${lead.area || '-'}`,
      `Mensaje: ${lead.message || '-'}`
    ].join('\n');
  }

  async function trySaveLead(lead) {
    const response = await fetch('/api/lead', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...lead, formEmail: config.contact.formEmail, source: 'sibratech-web' })
    });
    if (!response.ok) throw new Error('No se pudo guardar el lead localmente.');
    return response.json();
  }

  function setupLeadForm() {
    const form = $('[data-lead-form]');
    const status = $('[data-form-status]');
    if (!form) return;

    form.addEventListener('submit', async (event) => {
      event.preventDefault();
      const lead = formToObject(form);
      const message = buildLeadMessage(lead);
      const whatsappUrl = buildWhatsappUrl(message);
      const submit = form.querySelector('button[type="submit"]');

      submit.disabled = true;
      status.textContent = 'Preparando consulta...';

      try {
        await trySaveLead(lead);
        status.textContent = 'Lead guardado localmente. Abrimos WhatsApp para enviar la consulta.';
      } catch (error) {
        status.textContent = 'Abrimos WhatsApp. Para guardar CSV local, corré server.py.';
      } finally {
        submit.disabled = false;
        window.open(whatsappUrl, '_blank', 'noopener');
      }
    });
  }

  document.addEventListener('DOMContentLoaded', () => {
    hydrateContact();
    renderUnits();
    renderSocial();
    setupNav();
    setupLeadForm();
    setupReveal();
  });
})();
