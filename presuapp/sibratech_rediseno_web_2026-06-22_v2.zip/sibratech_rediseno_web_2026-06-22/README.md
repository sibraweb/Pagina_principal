# Sibratech Group — rediseño web modular

Primera versión local para rediseñar la home institucional de Sibratech Group sin mezclar todo en un solo HTML.

## Cómo probar

Opción rápida:

```bat
open_index.bat
```

Opción recomendada para probar formulario y guardar leads en CSV:

```bat
run_local.bat
```

Luego abrir:

```text
http://localhost:8080
```

Los leads de prueba se guardan en:

```text
data/leads.csv
```

## Estructura

```text
index.html                 # Home institucional
css/tokens.css             # Colores, tipografías, espaciados, efectos
css/styles.css             # Layout, componentes y responsive
js/site.config.js          # Datos corporativos, WhatsApp, email, redes, unidades
js/social-icons.js         # Íconos SVG inline para redes
js/main.js                 # Render dinámico, menú, formulario y animaciones
server.py                  # Servidor local + endpoint /api/lead
assets/logos/              # Logos originales y variantes exportables
assets/img/                # Imágenes raw y optimizadas
pages/                     # Subpáginas futuras / placeholders
templates/                 # Plantilla base para futuras subpáginas
docs/                      # Decisiones y notas técnicas
```

## Datos de contacto configurados

- WhatsApp visible: `+54 911 2165 1864`
- WhatsApp link: `5491126161864`
- Email visible: `info@sibratech.com`
- Email de formulario: `contacto@sibratech.com` — se deja como está si ya existe el flujo anterior.
- Recomendación: configurar `contacto@sibratech.com` como alias o redirección a `info@sibratech.com`.

## Redes

Están preparados los íconos de Instagram, WhatsApp, LinkedIn, Substack y YouTube. Completar URLs reales en `js/site.config.js`.

## Imágenes y logos

Guardar siempre los originales en `assets/img/raw/` o `assets/logos/source/`. Las versiones livianas para web van en `assets/img/optimized/` o `assets/logos/transparent/`.

## Próximo paso recomendado

1. Reemplazar los SVG draft por los logos definitivos.
2. Cargar URLs reales de LinkedIn, Substack y YouTube.
3. Aprobar estética de la home.
4. Crear subpáginas reales usando `templates/subpage-template.html`.

## Cambios incorporados

- Se agregó sección `Nuestro equipo` en la home con enlace a `pages/quienes-somos.html`.
